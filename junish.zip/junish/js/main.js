console.log('java script is running!');




let mobile_phones = document.querySelector("#mobile_phones");

function logID() {
    console.log(this.id);
}

mobile_phones.addEventListener('click',logID);


let vediography_cams = document.querySelector("#vediography_cams");

function logID() {
    console.log(this.id);
}

vediography_cams.addEventListener('click',logID);


let capture_cams = document.querySelector("#capture_cams");

function logID() {
    console.log(this.id);
}

capture_cams.addEventListener('click',logID);



let audio_recorder = document.querySelector("#audio_recorder");

function logID() {
    console.log(this.id);
}

audio_recorder.addEventListener('click',logID);



let disc = document.querySelector("#disc");

function logID() {
    console.log(this.id);
}

disc.addEventListener('click',logID);



let docs = document.querySelector("#docs");

function logID() {
    console.log(this.id);
}

docs.addEventListener('click',logID);


let capture = document.querySelector("#capture");

function logID() {
    console.log(this.id);
}

capture.addEventListener('click',logID);



let headphones = document.querySelector("#headphones");

function logID() {
    console.log(this.id);
}

headphones.addEventListener('click',logID);

let computer = document.querySelector("#computer");

function logID() {
    console.log(this.id);
}

computer.addEventListener('click',logID);

let phone_call = document.querySelector("#phone_call");

function logID() {
    console.log(this.id);
}

phone_call.addEventListener('click',logID);



let pc = document.querySelector("#pc");

function logID() {
    console.log(this.id);
}

pc.addEventListener('click',logID);


let speaker = document.querySelector("#speaker");

function logID() {
    console.log(this.id);
}

speaker.addEventListener('click',logID);